package com.Home.applicationRelated;

public class ReqWebServices {


private String restJSONWebServiceURL;
private String restXMLWebServiceURL;
	
public String getRestJSONWebServiceURL()
{
	return restJSONWebServiceURL;
}

public void setRestJSONWebServiceURL(String restJSONWebServiceURL)
{
	this.restJSONWebServiceURL=restJSONWebServiceURL;
}
public String getRestXMLWebServiceURL()
{
	return restXMLWebServiceURL;
}

public void setRestXMLWebServiceURL(String restXMLWebServiceURL)
{
	this.restXMLWebServiceURL=restXMLWebServiceURL;
}

}
