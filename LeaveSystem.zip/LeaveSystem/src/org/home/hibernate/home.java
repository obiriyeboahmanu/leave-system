package org.home.hibernate;

public class home {

}
